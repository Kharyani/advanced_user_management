from database import connect_db
from utils import hash_password

current_user = None


def register():

    conn = connect_db()
    cursor = conn.cursor()

    username = input("Enter Username: ")
    email = input("Enter Email: ")
    password = input("Enter Password: ")
    phone = input("Enter Phone: ")

    hashed_password = hash_password(password)

    try:

        cursor.execute("""
        INSERT INTO users (username, email, password, phone)
        VALUES (?, ?, ?, ?)
        """, (username, email, hashed_password, phone))

        conn.commit()

        print("Registration Successful!")

    except Exception as e:
        print("Error:", e)

    conn.close()


def login():

    global current_user

    conn = connect_db()
    cursor = conn.cursor()

    email = input("Enter Email: ")
    password = input("Enter Password: ")

    hashed_password = hash_password(password)

    cursor.execute("""
    SELECT * FROM users
    WHERE email=? AND password=?
    """, (email, hashed_password))

    user = cursor.fetchone()

    if user:
        current_user = user
        print("Login Successful!")

    else:
        print("Invalid Credentials")

    conn.close()


def view_profile():

    global current_user

    if current_user:

        print("\n===== PROFILE =====")

        print("ID:", current_user[0])
        print("Username:", current_user[1])
        print("Email:", current_user[2])
        print("Phone:", current_user[4])
        print("Role:", current_user[5])


def update_profile():

    global current_user

    conn = connect_db()
    cursor = conn.cursor()

    new_username = input("New Username: ")
    new_phone = input("New Phone: ")

    cursor.execute("""
    UPDATE users
    SET username=?, phone=?
    WHERE id=?
    """, (new_username, new_phone, current_user[0]))

    conn.commit()

    print("Profile Updated!")

    conn.close()


def delete_account():

    global current_user

    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
    DELETE FROM users WHERE id=?
    """, (current_user[0],))

    conn.commit()

    print("Account Deleted!")

    current_user = None

    conn.close()