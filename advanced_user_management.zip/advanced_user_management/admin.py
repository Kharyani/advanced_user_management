from database import connect_db


def view_all_users():

    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users")

    users = cursor.fetchall()

    print("\n===== ALL USERS =====")

    for user in users:
        print(user)

    conn.close()


def search_user():

    keyword = input("Enter Username or Email: ")

    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
    SELECT * FROM users
    WHERE username LIKE ?
    OR email LIKE ?
    """, (f"%{keyword}%", f"%{keyword}%"))

    users = cursor.fetchall()

    print("\n===== SEARCH RESULTS =====")

    for user in users:
        print(user)

    conn.close()


def admin_delete_user():

    user_id = input("Enter User ID to Delete: ")

    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
    DELETE FROM users
    WHERE id=?
    """, (user_id,))

    conn.commit()

    print("User Deleted Successfully!")

    conn.close()