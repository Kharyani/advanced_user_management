from database import create_table

import auth

from auth import (
    register,
    login,
    view_profile,
    update_profile,
    delete_account
)

from admin import (
    view_all_users,
    search_user,
    admin_delete_user
)

create_table()

while True:

    print("\n=================================")
    print(" ADVANCED USER MANAGEMENT SYSTEM ")
    print("=================================")

    print("1. Register")
    print("2. Login")
    print("3. Exit")

    choice = input("Enter Choice: ")

    # REGISTER
    if choice == "1":
        register()

    # LOGIN
    elif choice == "2":

        login()

        # CHECK LOGIN SUCCESS
        if auth.current_user:

            while True:

                print("\n===== USER MENU =====")

                print("1. View Profile")
                print("2. Update Profile")
                print("3. Delete Account")
                print("4. Logout")

                # ADMIN OPTION
                if auth.current_user[5] == "Admin":
                    print("5. Admin Panel")

                user_choice = input("Enter Choice: ")

                # VIEW PROFILE
                if user_choice == "1":
                    view_profile()

                # UPDATE PROFILE
                elif user_choice == "2":
                    update_profile()

                # DELETE ACCOUNT
                elif user_choice == "3":
                    delete_account()
                    break

                # LOGOUT
                elif user_choice == "4":
                    print("Logged Out!")
                    auth.current_user = None
                    break

                # ADMIN PANEL
                elif user_choice == "5":

                    if auth.current_user[5] == "Admin":

                        while True:

                            print("\n===== ADMIN PANEL =====")

                            print("1. View All Users")
                            print("2. Search User")
                            print("3. Delete User")
                            print("4. Back")

                            admin_choice = input("Enter Choice: ")

                            # VIEW USERS
                            if admin_choice == "1":
                                view_all_users()

                            # SEARCH USER
                            elif admin_choice == "2":
                                search_user()

                            # DELETE USER
                            elif admin_choice == "3":
                                admin_delete_user()

                            # BACK
                            elif admin_choice == "4":
                                break

                            else:
                                print("Invalid Choice")

                else:
                    print("Invalid Choice")

    # EXIT
    elif choice == "3":
        print("Goodbye!")
        break

    else:
        print("Invalid Choice")